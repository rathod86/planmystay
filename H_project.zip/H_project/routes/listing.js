const express = require ("express");
const mongoose = require('mongoose');
const router = express.Router();
//const Listing = require('../models/listing.js');

const Listing = require('../models/listing.js');


const { asyncHandler } = require("../utils/errorHandler.js");
const ExpressError = require("../utils/ExpressError.js");
const { validateListing, validateListingUpdate, validateId } = require("../utils/validateSchema.js");
const { isLoggedIn } = require("../middleware.js");

const listingsController = require('../controllers/listings.js');

const multer = require('multer');
const { storage } = require('../cloudConfig.js');
const upload = multer({ storage: storage });
// If you want to store files locally instead of Cloudinary, use this line instead
//const upload = multer({ dest: 'uploads/' });



// Test route for file upload (can be removed if not needed)
// router.post('/test-upload', upload.single('image'), (req, res) => {
//     console.log(req.file); // Information about the uploaded file
//     res.send('File uploaded successfully');
// });


// const { index } = require("../controllers/listings.js");

// GET /listings -> list all
router.get("/", asyncHandler(listingsController.index));

// GET /listings/new -> new form (must be before :id)
router.get("/new", isLoggedIn, listingsController.renderNewForm);

// POST /listings -> create
router.post("/", isLoggedIn, upload.single("listing[image]"), validateListing, asyncHandler(listingsController.createListing));

// GET /listings/:id -> show (must be after /new)
router.get("/:id", validateId, asyncHandler(listingsController.showlisting));

// GET /listings/:id/edit -> edit form
router.get("/:id/edit", isLoggedIn, validateId, asyncHandler(async (req, res) => {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
        throw new ExpressError("Invalid listing ID", 400);
    }
    const listing = await Listing.findById(id);
    if (!listing) {
        throw new ExpressError("Listing not found", 404);
    }
    res.render("listings/edit", { listing, layout: "layouts/boilerplate" });
}));

// PUT /listings/:id -> update
router.put("/:id",isLoggedIn, validateId, upload .single("listing[image]"), validateListingUpdate, asyncHandler(async (req, res) => {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
        throw new ExpressError("Invalid listing ID", 400);
    }
    const listing = await Listing.findByIdAndUpdate(id, { ...req.body.listing });
    if (!listing) {
        throw new ExpressError("Listing not found", 404);
    }
    res.redirect(`/listings/${id}`);
}));

// DELETE /listings/:id -> delete
router.delete("/:id",isLoggedIn, validateId, asyncHandler(async (req, res) => {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
        throw new ExpressError("Invalid listing ID", 400);
    }
    const deletedListing = await Listing.findByIdAndDelete(id);
    if (!deletedListing) {
        throw new ExpressError("Listing not found", 404);
    }
    res.redirect("/listings");
}));

module.exports = router;